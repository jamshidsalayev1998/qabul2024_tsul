<?php 

return [

	'LOG OUT' => 'ВЫЙТИ',
	'uz' => 'уз',
	'en' => 'ен',
	'ru' => 'ру',
	'Personal info' => 'Личная информация',
	'Excel export' => 'EXCEL EXPORT',
	'REJECT' => 'ВОЗВРАЩЕНИЕ',
	'ACCEPT' => 'ПРИНИМАТЬ',
	'PERSONAL INFO' => 'Личная информация',
	'PERSONAL INFORMATION' => 'Личная информация',
	'EDUCATION INFORMATION' => 'ИНФОРМАЦИЯ ОБ ОБРАЗОВАНИИ'

];









 ?>