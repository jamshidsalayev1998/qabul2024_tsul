<?php 

return [
	'Login' => 'Вход',
	'Sign up' => 'Регистрация',
	'Email' => 'Email',
	'Password' => 'Пароль',
	'Confirm password' => 'Подтвердить пароль',
	'Forgot' => 'Забыли пароль',
	'Sign in' => 'Вход',
	'Already have an account?' => 'Уже есть аккаунт?-',
	'Don’t have an account?' => 'У вас нету аккаунта?',
	'YEOJU TECHNICAL INSTITUTE IN TASHKENT' => 'ТЕХНИЧЕСКИЙ ИНСТИТУТ ЁДЖУ В ГОРОДЕ ТАШКЕНТ  ',
	'back' => 'Назад',
	'Language' => 'Язык',
	'Telefon raqam' => 'Номер телефона',
	'Logout' => 'Выйти',
	'New password will be sent to your phone number' => 'Новый пароль будет отправлен на ваш номер телефона',
	'Reset' => 'Отправить',
	'Forgot Your Password?' => 'Забыли Ваш пароль?',
	





];


 ?>