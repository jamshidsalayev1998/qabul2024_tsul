<?php 

return [

	'Insert your phone number'=>'Insert your phone number',
	'Send' => 'Send',


];





 ?>