<?php 

return [

	'LOG OUT' => 'ВЫЙТИ',
	'uz' => 'УЗ',
	'en' => 'ЕН',
	'ru' => 'РУ',
	'Personal info' => 'Личная информация',
	'Excel export' => 'EXCEL EXPORT',
	'REJECT' => 'ОТКЛОНИТЬ',
	'ACCEPT' => 'ПРИНЯТЬ',
	'PERSONAL INFO' => 'ЛИЧНАЯ ИНФОРМАЦИЯ',
	'PERSONAL INFORMATION' => 'ЛИЧНАЯ ИНФОРМАЦИЯ',
	'EDUCATION INFORMATION' => 'ИНФОРМАЦИЯ ОБ ОБРАЗОВАНИИ',
	'Delete ?' => 'Данные не могут быть восстановлены, вы действительно хотите удалить их ?',


];









 ?>