<?php 

return [
	'Registration' =>'Заполнить заявку',
	'Application status' => 'Статус заявки',
	'All applications' => 'Все заявки',
	'New applications' => 'Новые заявки',
	'Old applications' => 'Старые заявки',
	'Returned applications' => 'Отклонённые заявки',
	'Accepted applications' => 'Принятые заявки',
	'Application datas' => 'Информация о заявки',
	'Admins' => 'Админы',
	'Reports' => 'Отчёты',
	'Messages' => 'Сообщения',
	'By region' => 'По регионам', 
	'By faculty' => 'По факультету', 
	'Regions' => 'Регионы',
	'Areas' => 'Районы',
	'Faculties' => 'Факультеты',
	'Edu types' => 'Направления образования',
	'Language types' => 'Язык образования',
	'Applications' => 'Заявки',
	'Statistics' => 'Статистика',
	'All aplicants' => 'ВСЕ ЗАЯВКИ',
	'Accepted' => 'ПРИНЯТЫЕ',
	'Rejected' => 'ОТКЛОНЁННЫЕ',
	'Waiting' => 'ОЖИДАЮЩИЕ',
	'Applications menu' => 'МЕНЮ ЗАЯВКИ',
	'Additional options' => 'ДОПОЛНИТЕЛЬНЫЕ ОПЦИИ',
	'Countries' => 'Страны',



];


 ?>