<?php 

return [
	'Account didn`t activate' => 'аккаунт не активирован',
	'We already send activation link to your email' => 'мы отправили активации линка на вашей почте',
	'Click here for activate account' => 'для активировании аккаунта нажмите сюда',
];


 ?>