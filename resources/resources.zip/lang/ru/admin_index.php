<?php 
return [
	'S.N.M' => 'F.I.O',
	'Region' => 'Viloyat',
	'Status' => 'Holati',
	'PDF Export' => 'PDF Chop etish',
	'EXCEL Export' => 'EXCEL Chop etish',
];


 ?>