<?php 

return [
	'Login' => 'вход',
	'Sign up' => 'регистрация',
	'Email' => 'Email',
	'Password' => 'пароль',
	'Confirm password' => 'подтверждать пароль',
	'Forgot' => 'Forgot',
	'Sign in' => 'вход',
	'Already have an account?' => 'уже имеете аккаунт?-',
	'Don’t have an account?' => 'не имеете аккаунт?',
	'YEOJU TECHNICAL INSTITUTE IN TASHKENT' => 'ТЕХНИЧЕСКИЙ ИНСТИТУТ ЁДЖУ В ГОРОДЕ ТАШКЕНТ  ',
	'back' => 'Назад',
	'Language' => 'Язык',
	'Telefon raqam' => 'Номер телефона',
	'Logout' => 'выйти',





];


 ?>