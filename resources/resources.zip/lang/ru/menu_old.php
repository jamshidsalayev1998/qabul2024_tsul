<?php 

return [
	'Registration' =>'Заполнить заявку',
	'Application status' => 'Статус заявки',
	'All applications' => 'Все заявки',
	'New applications' => 'Новый заявки',
	'Old applications' => 'Старый заявки',
	'Returned applications' => 'Возвращенный заявки',
	'Accepted applications' => 'Полученные заявки',
	'Application datas' => 'Информация о заявки',
	'Admins' => 'Админы',
	'Reports' => 'Отчеты',
	'Messages' => 'Сообщения',
	'By region' => 'По регионам', 
	'By faculty' => 'По факультету', 
	'Regions' => 'Региони',
	'Areas' => 'Райони',
	'Faculties' => 'Факультети',
	'Edu types' => 'Типы образования',
	'Language types' => 'Типы языков',
	'Applications' => 'Заявки',
	'Statistics' => 'Статистика',
	'All aplicants' => 'ВСЕ ЗАЯВКИ',
	'Accepted' => 'ПРИНЯТИЙ',
	'Rejected' => 'ВОЗВРАЩЕННЫЙ',
	'Waiting' => 'ОЖИДАНИЯ',
	'Applications menu' => 'МЕНЮ ЗАЯВКИ',
	'Additional options' => 'ДОПОЛНИТЕЛЬНЫЕ ОПЦИИ',


];


 ?>