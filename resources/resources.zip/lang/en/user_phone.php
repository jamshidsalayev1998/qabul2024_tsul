<?php 

return [

	'Insert your phone number'=>'Insert your phone number',
	'Insert code'=> 'Kodni kiriting',
	
	'Send' => 'Send',


];





 ?>