<?php 

return [
	'Login' => 'Login',
	'Sign up' => 'Sign up',
	'Email' => 'Email',
	'Password' => 'Password',
	'Confirm password' => 'Confirm password',
	'Forgot' => 'Forgot',
	'Sign in' => 'Login',
	'Already you have an account?' => 'Already have an account?',
	'Don’t have an account?' => 'Don’t have an account?',
	'Send Password Reset Link' => 'Send Password Reset Link',
	'Reset Password' => 'Reset Password',
	'Language' => 'Language',
	'YEOJU TECHNICAL INSTITUTE IN TASHKENT' => 'YEOJU TECHNICAL INSTITUTE IN TASHKENT',
	'Forgot Your Password?' => 'Forgot your password?',
	'Logout' => 'Logout',
	'back' => 'Back',
	'Telefon raqam' => 'Phone number',
	'New password will be sent to your phone number' => 'New password will be sent to your phone number',
	'Reset' => 'Send',


];


 ?>