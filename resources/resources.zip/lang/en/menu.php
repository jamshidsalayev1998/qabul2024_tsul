<?php 

return [
	'Registration' =>'Registration',
	'Application status' => 'Application status',
	'All applications' => 'All applications',
	'New applications' => 'New applications',
	'Old applications' => 'Old applications',
	'Returned applications' => 'Rejected applications',
	'Accepted applications' => 'Accepted applications',
	'Application datas' => 'Application datas',
	'Admins' => 'Admins',
	'Reports' => 'Reports',
	'Messages' => 'Messages',
	'By region' => 'By region', 
	'By faculty' => 'By faculty', 
	'Regions' => 'Regions',
	'Areas' => 'Areas',
	'Faculties' => 'Faculties',
	'Edu types' => 'Edu types',
	'Language types' => 'Language types',
	'Applications' => 'Applications',
	'Statistics' => 'Statistics',
	'All aplicants' => 'ALL APPLICANTS',
	'Accepted' => 'ACCEPTED',
	'Rejected' => 'REJECTED',
	'Waiting' => 'WAITING',
	'Applications menu' => 'APPLICATIONS MENU',
	'Additional options' => 'ADDITIONAL OPTIONS',
	'Countries' => 'Countries',
	


];


 ?>