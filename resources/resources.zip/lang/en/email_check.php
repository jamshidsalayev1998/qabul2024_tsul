<?php 

return [
	'Account didn`t activate' => 'Account didn\'t activate',
	'Click here for activate account' => 'Click here for activate account',
	'We already send activation link to your email' => 'We already send activation link to your email',
	'Resend' => 'Resend',
	'Link sent again' => 'Link sent again'
];


 ?>