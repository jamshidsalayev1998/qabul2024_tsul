<?php 

return [

	'LOG OUT' => 'LOG OUT',
	'uz' => 'UZ',
	'en' => 'EN',
	'ru' => 'RU',
	'Personal info' => 'Personal info',
	'Excel export' => 'EXCEL EXPORT',
	'REJECT' => 'REJECT',
	'ACCEPT' => 'ACCEPT',
	'PERSONAL INFO' => 'PERSONAL INFO',
	'PERSONAL INFORMATION' => 'PERSONAL INFORMATION',
	'EDUCATION INFORMATION' => 'EDUCATION INFORMATION',
	'Delete ?' => 'The data cannot be recovered, you really want to delete it ?',

];









 ?>