<?php 
return [
	'S.N.M' => 'S.N.M',
	'Region' => 'Region',
	'Status' => 'Status',
	'PDF Export' => 'PDF Export',
	'EXCEL Export' => 'EXCEL Export',
];


 ?>