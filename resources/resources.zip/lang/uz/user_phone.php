<?php 

return [

	'Insert your phone number'=>'Telefon raqamingizni kiriting',
	'Insert code'=> 'Kodni kiriting',
	'Send' => 'Jo\'natish',


];





 ?>