<?php 

return [

	'LOG OUT' => 'CHIQISH',
	'uz' => 'UZ',
	'en' => 'EN',
	'ru' => 'RU',
	'Personal info' => 'SHAXSIY MALUMOTLAR',
	'Excel export' => 'EXCELGA EXPORT',
	'REJECT' => 'RAD ETISH',
	'ACCEPT' => 'QABUL QILISH',
	'PERSONAL INFO' => 'SHAXSIY MALUMOTLAR',
	'PERSONAL INFORMATION' => 'SHAXSIY MA\'LUMOTLAR',
	'EDUCATION INFORMATION' => 'TA\'LIM MA\'LUMOTLARI',
	'Delete ?' => 'Ma\'lumotni qayta tiklab bo\'lmaydi uni rostan ham o\'chirmoqchimisz ?',


];









 ?>