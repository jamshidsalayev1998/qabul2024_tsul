<?php 

return [
	'Login' => 'Kirish',
	'Sign up' => 'Ro\'yxatdan o\'tish',
	'Email' => 'Email',
	'Password' => 'Parol',
	'Confirm password' => 'Parolni takrorlang',
	'Forgot' => 'Unutdingizmi',
	'Sign in' => 'Kirish',
	'YEOJU TECHNICAL INSTITUTE IN TASHKENT' => 'TOSHKENT SHAHRIDAGI YODJU TEXNIKA INSTITUTI',
	'Already have an account?' => 'Ro\'yhatdan o\'tganmisiz?',
	'Don’t have an account?' => 'Saytimizda yangimisiz?',
	'Forgot Your Password?' => 'Parolni unutdingizmi?',
	'Language' => 'Til',
	'Logout' => 'Chiqish',
	'back' => 'Orqaga',
	'Telefon raqam' => 'Telefon raqam',
	'New password will be sent to your phone number' => 'Yangi parol telefon raqamingizga jo\'natiladi',
	'Reset' => 'Jo\'natish',





];


 ?>