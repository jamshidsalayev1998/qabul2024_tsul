<?php

return [
	'Registration' =>'Ariza to\'ldirish',
	'Application status' => 'Arizalar holati',
	'All applications' => 'Barcha arizalar',
	'New applications' => 'Yangi arizalar',
	'Old applications' => 'Eski arizalar',
	'Returned applications' => 'Qaytarilgan arizalar',
	'Accepted applications' => 'Qabul qilingan arizalar',
	'Application datas' => 'Ariza malumotlari',
	'Admins' => 'Adminlar',
	'Reports' => 'Hisobotlar',
	'Messages' => 'Habarlar',
	'By region' => 'Viloyat bo\'yicha',
	'By faculty' => 'Yo\'nalish bo\'yicha',
	'Regions' => 'Viloyatlar',
	'Areas' => 'Tumanlar',
	'Faculties' => 'Fakultetlar',
	'Edu types' => 'Ta\'lim turlari',
	'Language types' => 'Ta\'lim tillari',
	'Applications' => 'Arizalar',
	'Statistics' => 'Statistika',
	'All aplicants' => 'BARCHA ARIZALAR',
	'Accepted' => 'QABUL QILINGAN',
	'Rejected' => 'QAYTARILGAN',
	'Waiting' => 'KUTILYAPTI',
	'Applications menu' => 'Arizalar',
	'Additional options' => 'Qo\'shimcha',
	'Countries' => 'Mamlakatlar',
    'Talim tashkilotlari' => 'Talim tashkilotlari',
    'Statistika Magistratura' => 'Statistika Magistratura',
    'Statistika Akademik litsey' => 'Statistika Akademik litsey',
    'Statistika Yuridik texnikum' => 'Statistika Yuridik texnikum',

];


 ?>
