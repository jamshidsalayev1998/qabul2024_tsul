<?php 

return [
	'Account didn`t activate' => 'Akkountingiz aktivlashtirilmagan',

	'Click here for activate account' => 'Akkountingizni faollashtirish uchun bu yerga bosing',
	'We already send activation link to your email' => 'Biz allaqachon aktivatsiya havolasini emailingizga jo\'natdik',
	'Resend' => 'Qayta jo\'natish'

];


 ?>