<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title></title>
</head>
<style type="text/css">

body{
{{--	background-image: url({{ asset('newadmin/img/FON.jpg') }});--}}
	  font-family: DejaVu Sans;
}
@page {
	 margin: 0;
  	size: letter;
}
.pr_20{
	width: 20%;
}
.w-100{
	width: 100%;
}
.absolute{
	position: absolute;
}
.absolute div{
	position: relative;
}
.bg-white{
	background-color: white;
}
.mt-150{
	margin-top: 150px;

}
.border tr {
	border: 1px solid black;
}
table tr td{
	text-align: center;
	padding: 15px;
}
.border tr td{
	border: 1px solid black;

}

table tr td img{
	width: 100px;
	height: auto;
}
.f_img{
	width: 300px;
}
.ml-2{
	margin-left: 30px;
}
.mr-2{
	margin-right: 30px;
}
.mt-50{
	margin-top: 50px;
}
</style>
<body>
@php $locale = App::getLocale(); $name_l = 'name_'.$locale; @endphp

	{{-- <div class="w-100 absolute">
		<div class="pr_20"></div>
		<div class="pr_20"></div>
		<div class="pr_20">
			<img src="{{ asset('newadmin/img/logo.png') }}" class="w-100" >
		</div>
		<div class="pr_20"></div>
		<div class="pr_20"></div>
	</div> --}}
	<table class="w-100" style="margin-top: 30px" cellpadding="0" cellspacing="0">
		<tr>
			<td></td>
			<td>
				<img src="{{ asset('newadmin/img/tsul_logo.png') }}" >
				<br>
			</td>
			<td></td>
		</tr>
	</table>
	<table class="w-100 ml-2 mr-2  bg-white border" cellspacing="0">
		<tr>
			<td style="width: 170px;">
				@lang('petition.First name') <br><br>
				@lang('petition.Last name') <br><br>
				@lang('petition.Father`s name')
			</td>
			<td style="width: 170px;">
				{{ $petition->first_name }} <br><br>
				{{ $petition->last_name }} <br><br>
				{{ $petition->middle_name }}
			</td>
			<td rowspan="2">
				<div class="f_img">
					<img class="w-100" style="height: auto; max-height: 500px" src="{{ asset('users/documents/image') }}/{{ $petition->image }}">
				</div>

			</td>
		</tr>
		<tr>
			<td>
				@lang('petition.Passport seria')
			</td>
			<td>
				{{ $petition->passport_seria }}
			</td>
		</tr>
		<tr>
			<td>
				@lang('petition.Talim tashkiloti')<br> <br>
				@lang('petition.Faculty')<br> <br>
				@lang('petition.Type of Education')
			</td>
			<td colspan="2">
				@if($petition->high_school)
				{{ $petition->high_school->$name_l }}<br><br>
				@endif
				{{ $petition->getFaculty()->$name_l }}<br><br>
				{{ $petition->getEdutype()->$name_l }}
			</td>

		</tr>
		<tr>
			<td>
				Language of examination

			</td>
			<td rowspan="2" colspan="2">
				{{ $petition->getLanguagetype()->$name_l }}
			</td>
		</tr>
		<tr>
			<td>
				Language of Study

			</td>
		</tr>
	</table>
<div class="w-100" style="text-align: center">
	<p>
		{{$petition->high_school->$name_l}}
	</p>
</div>


</body>
</html>
