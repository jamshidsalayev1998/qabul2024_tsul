<table>
@php $locale = App::getLocale(); $name_l = 'name_'.$locale; @endphp
	
	<thead>
		<tr>
			<td>
				Abiturient full name
			</td>
			<td>
				Email/Phone
			</td>
			<td>
				Gender
			</td>
			<td>
				Birth date
			</td>
			<td>
				Country
			</td>
			<td>
				Region
			</td>
			<td>
				Area
			</td>
			<td>
				Address
			</td>
			<td>
				Citizenship
			</td>
			<td>
				Nationality
			</td>

			<td>
				Passport number
			</td>
			<td>
				Home phone
			</td>
			<td>
				Mother phone
			</td>
			<td>
				Father phone
			</td>
			<td>
				Mobile phone
			</td>
			<td>
				Name of school
			</td>
			<td>
				Type of school
			</td>
			<td>
				Graduation date
			</td>
			<td>
				Diplom number
			</td>
			<td>
				English degree
			</td>
			<td>
				Band
			</td>
			<td>
				Number(Certificate Number)
			</td>
			<td>
				Faculty
			</td>
			<td>
				Type of education 
			</td>
			<td>
				Language of education 
			</td>
			<td>
				Disability 
			</td>
			<td>
				Disability info 
			</td>

		</tr>
	</thead>
	<tbody>
		@foreach($petitions as $item)
		<tr>
			<td>
				{{ $item->last_name }} {{ $item->first_name }} {{ $item->middle_name }}
			</td>
			<td>
				@if(strpos($item->email , '@'))
				 email: {{ $item->email }}
				 @else
				 tel: {{ $item->email }}
				 @endif
			</td>
			<td>
				@if($item->gender == 0)
				Female
				@else
				Male
				@endif
			</td>
			<td>
				{{ $item->birth_date }}
			</td>
			<td>
				{{ $item->country}}
			</td>
			<td>
				{{ $item->region }}
			</td>
			<td>
				{{ $item->area }}
			</td>
			<td>
				{{ $item->address }}
			</td>
			<td>
				{{ $item->citizenship }}
			</td>
			<td>
				{{ $item->nationality }}
			</td>
			<td>
				{{ $item->passport_seria }}
			</td>
			<td>
				tel: {!!  $item->home_phone !!}
				
				
			</td>
			<td>
				tel: {!! $item->mother_phone !!}
			</td>
			<td>
				tel: {!!  $item->father_phone !!}
			</td>
			<td>
				tel: {!! $item->mobile_phone !!}
			</td>
			<td>
				{{ $item->school }}
			</td>
			<td>
				{{ $item->type_school }}
			</td>
			<td>
				{{ $item->graduation_date }}
			</td>
			<td>
				'{{ $item->diplom_number }}'
			</td>
			<td>
				{{ $item->endegree }}
			</td>
			<td>
				{{ $item->overall_score_english }}
			</td>
			<td>
				{{ $item->ilts_number }}
			</td>
			<td>
				{{ $item->faculty}}
			</td>
			<td>
				{{ $item->type_edu }}
			</td>
			<td>
				{{ $item->type_language }}
			</td>
			<td>
				{{ $item->disability }}
			</td>
			<td>
				{{ $item->disability_description }}
			</td>
			
		</tr>
		@endforeach
	</tbody>
</table>