@extends('admin.layouts.master')
@section('content')
<div class="container">
	<div class="row text-center w-100">
		<h1 class="text-center ml-auto mr-auto">Insert phone number</h1>
	</div>
</div>
@endsection