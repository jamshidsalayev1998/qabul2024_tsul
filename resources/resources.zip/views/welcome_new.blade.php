@extends('admin.layouts.master')
@section('content')

@endsection